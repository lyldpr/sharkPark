import IMG_0885 from '/pages/posts/IMG_0885.jpeg'
import Image from 'next/image'

export default function login() {
    return (
        
        <>
         <center>
            <Image src={IMG_0885} height={250} width={300} />
          </center>
            <title>SharkPark</title>
            <center>
            <h1 className = "font"> Thank you for listing your spot with SharkPark!</h1>
        <h3 className= "font"> You will recieve an email confirmation of your listing once your 
            proof of ownership is verified.  </h3>
            </center>
            
            
            
            
            <style>{`
            
            .font {
            font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
            Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
            sans-serif; }
            
            
            `}</style></>


    )

}