import Image from 'next/image'
import IMG_0885 from '/pages/posts/IMG_0885.jpeg'


export default function parkingSpots() {
    return( 
        <><title>SharkPark</title><center>
            <Image src={IMG_0885} height={250} width={300} />
        </center>
        <center>
        <h1 className = "font"> Welcome! </h1>

        <h2 className = "font">  Thanks for creating an account with SharkPark! </h2>
            </center>
                <a href="http://localhost:3000/posts/enter-location">
            <center>
                    
    
                    <input class="Button" type="button" value="Find a Parking Spot"></input>
                </center>
            </a>
            <style>{`
            .font {
                font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
            Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
            sans-serif;
            }
    .Button {
    height: 40px;
    padding: 0px  10px 35px 10px;
    border-radius: 5px;
    line-height: 38px;
    border: 1.5px solid gray;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
            Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
            sans-serif;
    }
        .Button:hover {
             border: 3px solid gray;

         }
         `}</style></>

    )
}