
import Image from 'next/image'
import IMG_0885 from '/pages/posts/IMG_0885.jpeg'

export default function enterLocation() {
    return(

    <><main>
       
            <title>SharkPark</title>
        

        <center>
            <Image src={IMG_0885} height = {250} width= {300}/>
        </center>
            
        <center>
            <h2 class="label"> Find a Parking Spot </h2>
        </center>

        <center>
            <label class = "label"> Parking From... </label>
            <input class="font" type="text" placeholder="Start Date "></input>
        <div class="DatePicker-tether DatePicker-tether-SearchDateTimePickers-transient-start tether-element tether-element-attached-top tether-target-attached-bottom tether-element-attached-left tether-target-attached-left tether-enabled" style="top: 0px; left: 0px; position: absolute; transform: translateX(16px) translateY(271px) translateZ(0px);"><div class="DatePicker-calendar calendar-start"><div class="DayPicker" lang="en"><div class="DayPicker-wrapper" tabindex="0"><div class="DatePickerCalendarNavigation DayPicker-NavBar"><button class="Button DayPicker-NavButton DayPicker-NavButton--next" type="button"><svg viewBox="0 0 1024 1024" fill="currentColor" class="Icon "><path d="M841.6 518.4c0 17.1-4.3 29.9-17.1 38.4L257 1013.4c-21.3 17.1-46.9 12.8-64-8.5s-12.8-46.9 8.5-64l516.4-426.8L205.7 87.4c-21.3-12.8-25.6-42.7-8.5-68.3 12.8-21.3 42.7-25.6 64-8.5l563.3 469.5c12.9 8.5 17.1 21.3 17.1 38.3z"></path></svg></button></div><div class="DayPicker-Months"><div class="DayPicker-Month" role="grid"><div class="DayPicker-Caption" role="heading"><div>October 2021</div></div><div class="DayPicker-Weekdays" role="rowgroup"><div class="DayPicker-WeekdaysRow" role="row"><div class="DayPicker-Weekday" role="columnheader"><abbr title="Sunday">S</abbr></div><div class="DayPicker-Weekday" role="columnheader"><abbr title="Monday">M</abbr></div><div class="DayPicker-Weekday" role="columnheader"><abbr title="Tuesday">T</abbr></div><div class="DayPicker-Weekday" role="columnheader"><abbr title="Wednesday">W</abbr></div><div class="DayPicker-Weekday" role="columnheader"><abbr title="Thursday">T</abbr></div><div class="DayPicker-Weekday" role="columnheader"><abbr title="Friday">F</abbr></div><div class="DayPicker-Weekday" role="columnheader"><abbr title="Saturday">S</abbr></div></div></div><div class="DayPicker-Body" role="rowgroup"><div class="DayPicker-Week" role="row"><div class="DayPicker-Day DayPicker-Day--disabled DayPicker-Day--outside" tabindex="-1" role="gridcell" aria-label="Sun Sep 26 2021" aria-disabled="true" aria-selected="false"><span data-date="09/26/2021">26</span></div><div class="DayPicker-Day DayPicker-Day--disabled DayPicker-Day--outside" tabindex="-1" role="gridcell" aria-label="Mon Sep 27 2021" aria-disabled="true" aria-selected="false"><span data-date="09/27/2021">27</span></div><div class="DayPicker-Day DayPicker-Day--disabled DayPicker-Day--outside" tabindex="-1" role="gridcell" aria-label="Tue Sep 28 2021" aria-disabled="true" aria-selected="false"><span data-date="09/28/2021">28</span></div><div class="DayPicker-Day DayPicker-Day--disabled DayPicker-Day--outside" tabindex="-1" role="gridcell" aria-label="Wed Sep 29 2021" aria-disabled="true" aria-selected="false"><span data-date="09/29/2021">29</span></div><div class="DayPicker-Day DayPicker-Day--disabled DayPicker-Day--outside" tabindex="-1" role="gridcell" aria-label="Thu Sep 30 2021" aria-disabled="true" aria-selected="false"><span data-date="09/30/2021">30</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="0" role="gridcell" aria-label="Fri Oct 01 2021" aria-disabled="true" aria-selected="false"><span data-date="10/01/2021">1</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Sat Oct 02 2021" aria-disabled="true" aria-selected="false"><span data-date="10/02/2021">2</span></div></div><div class="DayPicker-Week" role="row"><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Sun Oct 03 2021" aria-disabled="true" aria-selected="false"><span data-date="10/03/2021">3</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Mon Oct 04 2021" aria-disabled="true" aria-selected="false"><span data-date="10/04/2021">4</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Tue Oct 05 2021" aria-disabled="true" aria-selected="false"><span data-date="10/05/2021">5</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Wed Oct 06 2021" aria-disabled="true" aria-selected="false"><span data-date="10/06/2021">6</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Thu Oct 07 2021" aria-disabled="true" aria-selected="false"><span data-date="10/07/2021">7</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Fri Oct 08 2021" aria-disabled="true" aria-selected="false"><span data-date="10/08/2021">8</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Sat Oct 09 2021" aria-disabled="true" aria-selected="false"><span data-date="10/09/2021">9</span></div></div><div class="DayPicker-Week" role="row"><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Sun Oct 10 2021" aria-disabled="true" aria-selected="false"><span data-date="10/10/2021">10</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Mon Oct 11 2021" aria-disabled="true" aria-selected="false"><span data-date="10/11/2021">11</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Tue Oct 12 2021" aria-disabled="true" aria-selected="false"><span data-date="10/12/2021">12</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Wed Oct 13 2021" aria-disabled="true" aria-selected="false"><span data-date="10/13/2021">13</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Thu Oct 14 2021" aria-disabled="true" aria-selected="false"><span data-date="10/14/2021">14</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Fri Oct 15 2021" aria-disabled="true" aria-selected="false"><span data-date="10/15/2021">15</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Sat Oct 16 2021" aria-disabled="true" aria-selected="false"><span data-date="10/16/2021">16</span></div></div><div class="DayPicker-Week" role="row"><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Sun Oct 17 2021" aria-disabled="true" aria-selected="false"><span data-date="10/17/2021">17</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Mon Oct 18 2021" aria-disabled="true" aria-selected="false"><span data-date="10/18/2021">18</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Tue Oct 19 2021" aria-disabled="true" aria-selected="false"><span data-date="10/19/2021">19</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Wed Oct 20 2021" aria-disabled="true" aria-selected="false"><span data-date="10/20/2021">20</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Thu Oct 21 2021" aria-disabled="true" aria-selected="false"><span data-date="10/21/2021">21</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Fri Oct 22 2021" aria-disabled="true" aria-selected="false"><span data-date="10/22/2021">22</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Sat Oct 23 2021" aria-disabled="true" aria-selected="false"><span data-date="10/23/2021">23</span></div></div><div class="DayPicker-Week" role="row"><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Sun Oct 24 2021" aria-disabled="true" aria-selected="false"><span data-date="10/24/2021">24</span></div><div class="DayPicker-Day DayPicker-Day--disabled" tabindex="-1" role="gridcell" aria-label="Mon Oct 25 2021" aria-disabled="true" aria-selected="false"><span data-date="10/25/2021">25</span></div><div class="DayPicker-Day DayPicker-Day--selected DayPicker-Day--today" tabindex="-1" role="gridcell" aria-label="Tue Oct 26 2021" aria-disabled="false" aria-selected="true"><span data-date="10/26/2021">26</span></div><div class="DayPicker-Day" tabindex="-1" role="gridcell" aria-label="Wed Oct 27 2021" aria-disabled="false" aria-selected="false"><span data-date="10/27/2021">27</span></div><div class="DayPicker-Day" tabindex="-1" role="gridcell" aria-label="Thu Oct 28 2021" aria-disabled="false" aria-selected="false"><span data-date="10/28/2021">28</span></div><div class="DayPicker-Day" tabindex="-1" role="gridcell" aria-label="Fri Oct 29 2021" aria-disabled="false" aria-selected="false"><span data-date="10/29/2021">29</span></div><div class="DayPicker-Day" tabindex="-1" role="gridcell" aria-label="Sat Oct 30 2021" aria-disabled="false" aria-selected="false"><span data-date="10/30/2021">30</span></div></div><div class="DayPicker-Week" role="row"><div class="DayPicker-Day" tabindex="-1" role="gridcell" aria-label="Sun Oct 31 2021" aria-disabled="false" aria-selected="false"><span data-date="10/31/2021">31</span></div><div class="DayPicker-Day DayPicker-Day--outside" tabindex="-1" role="gridcell" aria-label="Mon Nov 01 2021" aria-disabled="true" aria-selected="false"><span data-date="11/01/2021">1</span></div><div class="DayPicker-Day DayPicker-Day--outside" tabindex="-1" role="gridcell" aria-label="Tue Nov 02 2021" aria-disabled="true" aria-selected="false"><span data-date="11/02/2021">2</span></div><div class="DayPicker-Day DayPicker-Day--outside" tabindex="-1" role="gridcell" aria-label="Wed Nov 03 2021" aria-disabled="true" aria-selected="false"><span data-date="11/03/2021">3</span></div><div class="DayPicker-Day DayPicker-Day--outside" tabindex="-1" role="gridcell" aria-label="Thu Nov 04 2021" aria-disabled="true" aria-selected="false"><span data-date="11/04/2021">4</span></div><div class="DayPicker-Day DayPicker-Day--outside" tabindex="-1" role="gridcell" aria-label="Fri Nov 05 2021" aria-disabled="true" aria-selected="false"><span data-date="11/05/2021">5</span></div><div class="DayPicker-Day DayPicker-Day--outside" tabindex="-1" role="gridcell" aria-label="Sat Nov 06 2021" aria-disabled="true" aria-selected="false"><span data-date="11/06/2021">6</span></div></div></div></div></div></div></div></div></div>
            <input class="font" type="text" placeholder="End Date " ></input>
            <input class="font" type="text" placeholder="Start Time" ></input>
            <input class="font" type="text" placeholder="End Time" ></input>
        </center>

        <div class="wrapper">
            <img class="search-icon" src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDU2Ljk2NiA1Ni45NjYiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDU2Ljk2NiA1Ni45NjY7IiB4bWw6c3BhY2U9InByZXNlcnZlIiB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4Ij4KPHBhdGggZD0iTTU1LjE0Niw1MS44ODdMNDEuNTg4LDM3Ljc4NmMzLjQ4Ni00LjE0NCw1LjM5Ni05LjM1OCw1LjM5Ni0xNC43ODZjMC0xMi42ODItMTAuMzE4LTIzLTIzLTIzcy0yMywxMC4zMTgtMjMsMjMgIHMxMC4zMTgsMjMsMjMsMjNjNC43NjEsMCw5LjI5OC0xLjQzNiwxMy4xNzctNC4xNjJsMTMuNjYxLDE0LjIwOGMwLjU3MSwwLjU5MywxLjMzOSwwLjkyLDIuMTYyLDAuOTIgIGMwLjc3OSwwLDEuNTE4LTAuMjk3LDIuMDc5LTAuODM3QzU2LjI1NSw1NC45ODIsNTYuMjkzLDUzLjA4LDU1LjE0Niw1MS44ODd6IE0yMy45ODQsNmM5LjM3NCwwLDE3LDcuNjI2LDE3LDE3cy03LjYyNiwxNy0xNywxNyAgcy0xNy03LjYyNi0xNy0xN1MxNC42MSw2LDIzLjk4NCw2eiIgZmlsbD0iIzAwMDAwMCIvPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K" />
            <input class="search" placeholder="Enter City or Zipcode" type="text" />
            <img class="clear-icon" src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDUxLjk3NiA1MS45NzYiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxLjk3NiA1MS45NzY7IiB4bWw6c3BhY2U9InByZXNlcnZlIiB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4Ij4KPGc+Cgk8cGF0aCBkPSJNNDQuMzczLDcuNjAzYy0xMC4xMzctMTAuMTM3LTI2LjYzMi0xMC4xMzgtMzYuNzcsMGMtMTAuMTM4LDEwLjEzOC0xMC4xMzcsMjYuNjMyLDAsMzYuNzdzMjYuNjMyLDEwLjEzOCwzNi43NywwICAgQzU0LjUxLDM0LjIzNSw1NC41MSwxNy43NCw0NC4zNzMsNy42MDN6IE0zNi4yNDEsMzYuMjQxYy0wLjc4MSwwLjc4MS0yLjA0NywwLjc4MS0yLjgyOCwwbC03LjQyNS03LjQyNWwtNy43NzgsNy43NzggICBjLTAuNzgxLDAuNzgxLTIuMDQ3LDAuNzgxLTIuODI4LDBjLTAuNzgxLTAuNzgxLTAuNzgxLTIuMDQ3LDAtMi44MjhsNy43NzgtNy43NzhsLTcuNDI1LTcuNDI1Yy0wLjc4MS0wLjc4MS0wLjc4MS0yLjA0OCwwLTIuODI4ICAgYzAuNzgxLTAuNzgxLDIuMDQ3LTAuNzgxLDIuODI4LDBsNy40MjUsNy40MjVsNy4wNzEtNy4wNzFjMC43ODEtMC43ODEsMi4wNDctMC43ODEsMi44MjgsMGMwLjc4MSwwLjc4MSwwLjc4MSwyLjA0NywwLDIuODI4ICAgbC03LjA3MSw3LjA3MWw3LjQyNSw3LjQyNUMzNy4wMjIsMzQuMTk0LDM3LjAyMiwzNS40NiwzNi4yNDEsMzYuMjQxeiIgZmlsbD0iIzAwMDAwMCIvPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+Cjwvc3ZnPgo=" />
        </div> 
  
        <h1>
            <a href="http://localhost:3000/posts/parking-spots">
                    <center>
                        <input class="Button" type="button" value="Show Available Parking Spots"></input>
                    </center>
            </a>
        
        </h1>   

        </main>
        
        <style>{`

element.style {
    top: 0px;
    left: 0px;
    position: absolute;
    transform: translateX(16px) translateY(271px) translateZ(0px);
}
.DatePicker-tether {
    z-index: 800;
}
*, ::before, ::after {
    border-color: var(--chakra-colors-gray-200);
    overflow-wrap: break-word;
}


        .input-container input {
            border: none;
            box-sizing: border-box;
            outline: 0;
            padding: .75rem;
            position: relative;
            width: 100%;
        }
        input[type="date"]::-webkit-calendar-picker-indicator {
            background: transparent;
            bottom: 0;
            color: transparent;
            cursor: pointer;
            height: auto;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
            width: auto;
        }
        .label {
            font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
            Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
            sans-serif;
            margin: 1.5rem;

        }
        .x .c2-p {
            transform: translateZ(0px);
        }
        .x .c2-n {
            background-color: rgb(254, 218, 213);
        }
        .x .c2-m {
            border-radius: 50%;
        }
        .font {
            font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
            Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
            sans-serif;
            padding: 5px;
            border: 1.5px solid Gainsboro;
            border-radius: 5px;
            margin: 5px;
            display:inline-grid;
            
            
        }
         .font:focus {
            border: 3px solid navy;
        }
        .Button {
            height: 40px;
            padding: 0px  10px 35px 10px;
            border-radius: 5px;
            line-height: 38px;
            border: 1.5px solid gray;
            font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
                    Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
                    sans-serif;
        }
                .Button:hover {
                     border: 3px solid gray;
   
                 }
        .wrapper {
            position: relative;
            display: flex;
            min-width: 100px;
        }
        .search-icon {
            position: absolute;
            top: 35px;
            left: 25px;
            width: 14px;
        }

    .clear-icon {
    position: absolute;
    top: 8px;
    right: 8px;
    width: 10px;
    cursor: pointer;
    
  }
  .search {
    border: 1.5px solid Gainsboro;
    border-radius: 5px;
    height: 50px;
    width: 100%;
    padding: 2px 23px 2px 30px;
    outline: 0;
    background-color: white;
    margin: 12px;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
            Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
            sans-serif;
    
  }
  .search:focus {
    border: 3px solid navy;
    background-color: white;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
            Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
            sans-serif;

  }


    `}</style></>
    )


}