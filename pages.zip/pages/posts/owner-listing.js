import Image from 'next/image'
import IMG_0885 from '/pages/posts/IMG_0885.jpeg'
import React, { useState } from 'react';

export default function ownerListing() {
    return (
      
      <><main>
            {/* SharkPark on the browser tab*/}
              
                  <title>SharkPark</title>
              
        

        <center>

            {/* SharkPark Logo on the page */}
            
            <Image src={IMG_0885} height = {250} width= {300}/>

            <p>
            <label className = "proof"> </label>
              {/* Location textbox */}
              <input class = "fileButton" type="button" value= "Upload Proof of Ownership"></input>
              
             
              <input className = "card" type="text" name="Uname" placeholder="Spot Address"></input>
              
              {/* Number of Spots textbox */}
              
              <input className = "card" type="text" name="Pword" placeholder="Number of Spots"></input>
              
              
              <input class = "picButton" type="button" value="Upload Image"></input>

                <a href="http://localhost:3000/posts/listed">
              <input class= "Button" type="button" value="List"></input>
                </a>

            </p>

        </center>
      
      
      
      
      
    <style>{`
    .picButton {
      position: absolute;
      right: 320px;
      
      top: 462px;
      bottom: 0px;
      height: 42px;
      width: 100px;
      padding: 5px;
      border-radius: 1px;
      line-height: 20px;
      border: 1.5px solid gray;
      font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
              Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
              sans-serif;
      
      }
      .picButton:hover {
        border: 3px solid gray;
    }
    .fileButton {
      position: absolute;
      right: 500px;
      
      top: 300px;
      bottom: 0px;
      bottom: 0px;
      height: 42px;
      width: 200px;
      padding: 0px  5px 30px 5px;
      border-radius: 1px;
      line-height: 38px;
      border: 1.5px solid gray;
      font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
              Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
              sans-serif;
      
      }
      .fileButton:hover {
          border: 3px solid gray;
      }
    
    .title {
        font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
            Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
            sans-serif;
            margin: 2rem;
      }
    .card {
      display: block;
      margin: 2rem;
      flex-basis: 45%;
      padding: 1rem;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: inherit;
      text-decoration: none;
      border: 1px solid #eaeaea;
      border-radius: 10px;
      transition: color 0.15s ease, border-color 0.15s ease;
      font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
            Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
            sans-serif;
            width:20rem;
    }
    .proof {
      display: block;
      margin: 2rem;
      flex-basis: 45%;
      padding: 0px  5px 30px 5px;
      align-items: center;
      justify-content: left;
      text-align: center;
      color: inherit;
      text-decoration: none;
      border: 1.5px solid white;
      border-radius: 5px;
      transition: color 0.15s ease, border-color 0.15s ease;
      font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
            Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
            sans-serif;
            width:5rem;
    }
    
  .Button {
    centered-mode: true;
    height: 40px;
    padding: 0px  10px 35px 10px;
    border-radius: 5px;
    line-height: 38px;
    border: 1.5px solid gray;
    font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
            Oxygen, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue,
            sans-serif;
    width: 4rem;
    }
    .Button:hover {
        border: 3px solid gray;
   
    }
  
    `}</style>

    
    </main></>
    )
  }